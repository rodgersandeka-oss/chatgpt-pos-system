# NextLevel Device World POS — server-backed starter

## Included
- Server-side login sessions (HttpOnly, SameSite cookie)
- Password hashing with Node.js `scrypt` (no plaintext password storage)
- Inventory create/edit, CSV import/export, low-stock reporting
- Checkout with stock deduction, serial/IMEI capture and uniqueness checks
- Cash, M-Pesa receipt-code recording, and card payment recording
- Receipts, sales export, reports, user roles, settings, backup/restore
- Persistent JSON data file on the server

## Run locally
1. Install Node.js 20 or newer.
2. Extract the ZIP to a folder.
3. Open a terminal in that folder and run: `node server.js`
4. Visit `http://127.0.0.1:3000`
5. Initial login: `admin` / `ChangeMe123!`
6. Create a new admin account with a unique username and strong password, sign out, test that account, then delete the initial `admin` account.
7. Keep the folder's `data.json` backed up securely.

## Important deployment and payment limitations
This is a functional single-store application foundation, not yet a hardened public production deployment. The built-in JSON store is suitable for local testing/small single-process use, not concurrent multi-branch operation. Before exposing it to the internet, use HTTPS, a managed database (e.g. PostgreSQL), rate limiting, audit logging, stronger session lifecycle controls, automated off-site backups, monitoring, and a security review. Run the server behind a reverse proxy and bind it to localhost.

M-Pesa and card payments are only recorded after you independently verify payment. No money is charged and no M-Pesa STK Push or callback verification is included. Live M-Pesa requires Safaricom Daraja credentials, a public HTTPS callback endpoint, and server-side transaction verification. Card processing requires a PCI-compliant payment provider; do not store card numbers or CVVs in this app.

The initial product list contains sample products and must be reconciled against your actual stock before business use. Use Settings > Download full backup before imports or edits.
